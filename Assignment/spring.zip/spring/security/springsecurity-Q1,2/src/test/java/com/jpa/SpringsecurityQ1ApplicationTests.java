package com.jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringsecurityQ1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
