package com.jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springsecurity2A1Application {

	public static void main(String[] args) {
		SpringApplication.run(Springsecurity2A1Application.class, args);
	}

}
