package com.jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springsecurity2A1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
