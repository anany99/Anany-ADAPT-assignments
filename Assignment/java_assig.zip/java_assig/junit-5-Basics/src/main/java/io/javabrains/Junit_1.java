package io.javabrains;

public class Junit_1 {

}
