
public class array {

	public static void main(String[] args) {
//		int [] marks = new int [5];
//		marks[0] = 100;
//		marks[1] = 56;
//		marks[2] = 66;
//		marks[3] = 86;
//		marks[4] = 26;
//		System.out.println(marks[3]);
        int [] marks = {100 , 56, 66, 86, 26};
//        String [] students = {"jerry", "tom", "tim", "elon"};
        System.out.println(marks[0]);
        System.out.println(marks.length);
//        System.out.println(students[2]);
//        System.out.println(students.length);
        for(int i=marks.length -1;i>=0;i--) {
        	System.out.println(marks[i]);
        }
	}

}
