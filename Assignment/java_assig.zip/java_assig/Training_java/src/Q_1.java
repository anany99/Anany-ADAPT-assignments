import java.util.Scanner;
public class Q_1 {

	public static void main(String[] args) {
		Scanner am = new Scanner(System.in);
		int D1,D2,D3,C;
		int num = am.nextInt();
		C = num;
		D1 = C%10;
		C = C/10;
		D2 = C%10;
		C = C/10;
		D3 = C%10;
		int result = (D1*D1*D1) + (D2*D2*D2) + (D3*D3*D3);
		System.out.println(result);
		if(num == result) {
			System.out.println("correct");
		}
		else
		{
			System.out.println("incorrect");
		}	
		}
	}


