
public class java_methods {
//	static void multiplications(int n){
//		for (int i=1;i<=10;i++) {
//			System.out.format("%d X %d = %d\n", n, i, n*i ); 
//		}
//	}
//  
	static int sumRec(int n) {
		if(n==1) {
			return 1;
		}
		return n + sumRec(n-1);  
	}
	public static void main(String[] args) {
//		multiplications(7);
		int c = sumRec(4);
		System.out.println(c);
	}
// 
}
