
public class Q_6 {
    public static void main(String[] args) {
	Login obj = new Login();
	obj.loginUser("Ajay", "password");
	}
}

class Login{
	String userId = "Ajay",password = "password";
	public String loginUser(String user, String pass) {
		int attempts = 3;
		if (attempts!=0)
		{
			if (userId == "Ajay" && password =="password")
			{
				System.out.print("welcome Ajay");
			}
			else
			{
				System.out.print("wrong credentials");
			}
		}
		else
		{
			System.out.print("contact admin");
		}
		return pass;
			
		
	}
}