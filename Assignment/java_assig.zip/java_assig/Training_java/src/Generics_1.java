import java.util.HashSet;
import java.util.Set;
public class Generics_1 {
		    
		        // Creating a HashSet
	      public static void main(String[] args) {
		        Set<String> Employee = new HashSet<>();
		        
		        {
		        // Adding new elements to the HashSet
		        Employee.add("Id-RA1811003030558");
		        Employee.add("Name-Ayushman jha");
		        Employee.add("Salary-30000");
		        Employee.add("Department-Java Full Strack Developer");
		        System.out.println(Employee);
		        
		    }
		    	}
		       
		        	

	}