
public class Assignment3Q1 {

	public static void main(String[] args) {
		String str = "Hello World";
        int c = str.length();
        System.out.println("The String has " +c +" characters");

	}

}
