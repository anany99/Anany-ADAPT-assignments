
public class Generics_3 {

}
