
public class Practice {

	public static void main(String[] args) {
		Person p1 = new Person();
        p1.name = "Anany";
        p1.age = 21;
        
        Person p2 = new Person();
        p2.name = "Mehta";
        p2.age = 23;
        
        System.out.println(p1.name+" " + p1.age);
        System.out.println(p2.name+" " + p2.age);
        
        
        p1.sleep();
        p2.reading();
        p1.reading(3);
        p2.sleep(1);
        
        System.out.println("total Person : " + Person.count);
          
        actor a1 = new actor(24, "aman");
        a1.sleep();
	}

}

class actor extends Person {
	public actor(int age, String name) {
		super(age, name);
	}
}

class Person {
	String name;
	int age;
	
	static int count;
	
	public Person() {
		count++;
		System.out.println("creating object"); 
	}
	
	public Person (int new_age, String new_name) {
		this.name = name;
		this.age = age;		
	}
	
	void sleep() {
		System.out.println(name + " is sleeping");
	}
	void sleep(int times) {
		System.out.println(name + " is sleeping " + times + " times a day");
	}
	void reading() {
		System.out.println(name + " is reading");
	}
	void reading(int num_of_books) {
		System.out.println(name + " reading " + num_of_books + " Books");
	}
	void doingwork() {
		System.out.println("Person is sleeping");
	}
}