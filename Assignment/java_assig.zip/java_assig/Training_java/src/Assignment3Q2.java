public class Assignment3Q2 
{
public static void main(String args[]){
String s="Hello,";
s=s.concat(" How are you?");
System.out.println(s);
}
}