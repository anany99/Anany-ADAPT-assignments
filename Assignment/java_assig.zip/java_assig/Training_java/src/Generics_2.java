import java.util.HashMap;
public class Generics_2 {

 public static void main(String[] args)
 {

     HashMap<Integer,Double> map = new HashMap<Integer,Double>();

     map.put(10, 10.1);
     map.put(20, 20.2);
     map.put(30, 30.3);
     map.put(40, 40.4);
     map.put(50, 50.5);
     map.put(60, 60.6);
     map.put(70, 70.7);
     map.put(80, 80.8);
     map.put(90, 90.9);
     map.put(100, 100.10);


     System.out.println(map);

    
     }
 }