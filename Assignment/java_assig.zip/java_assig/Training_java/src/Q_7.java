
 class SearchArray{
	 public boolean searchArray(int[] arr,int checking_values) {
		 boolean searchArray = false;
		 for (int a : arr) {
		     if (a == checking_values) {
		    	searchArray = true;
		    	break;
		     }
	      }    
	 
	 if (searchArray) {
		 System.out.print(checking_values+ " is present");
	 }
	 else {
		 System.out.print("not present");
	 }
	 return searchArray;
 }
 }
 public class Q_7 {

		public static void main(String[] args) {
			int arr[] = { 5,12,14,6,78,6,78,19,1,23,26,35,37,7,52,86,47};
			int checking_values = 19;
			SearchArray obj = new SearchArray();
			obj.searchArray(arr, checking_values);
		}

	}