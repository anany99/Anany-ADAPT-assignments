import java.util.Scanner;

public class Q_3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Suject 1 marks : ");
		float Subject1 = sc.nextFloat();
		System.out.println("Suject 2 marks : ");
		float Subject2 = sc.nextFloat();
		System.out.println("Suject 3 marks : ");
		float Subject3 = sc.nextFloat();
		System.out.println("Suject 4 marks : ");
		float Subject4 = sc.nextFloat();
		
		float percentage = ((Subject1 + Subject2 + Subject3 + Subject4)/400)*100;
		
		System.out.println("percentage : ");
		System.out.println(percentage);
	}

}
