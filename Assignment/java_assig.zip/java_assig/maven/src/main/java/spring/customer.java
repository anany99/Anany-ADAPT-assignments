package spring;

public class customer {

}
