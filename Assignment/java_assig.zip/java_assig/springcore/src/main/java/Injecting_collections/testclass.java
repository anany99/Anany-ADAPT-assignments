package Injecting_collections;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class testclass {

	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("Injecting_collections/collections.xml");
		Collections collections1=(Collections) context.getBean("Collections1");
		System.out.println(collections1.getName());
		System.out.println(collections1.getPhones());
		System.out.println(collections1.getAddress());
		System.out.println(collections1.getCourses());
	}

}
