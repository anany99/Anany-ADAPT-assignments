package reference_inject;

public class a {

	private int X;
	@Override
	public String toString() {
		return "a [x=" + X + ", ob=" + ob + "]";
	}
	public a() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getX() {
		return X;
	}
	public void setX(int x) {
		this.X = x;
	}
	public b getOb() {
		return ob;
	}
	public void setOb(b ob) {
		this.ob = ob;
	}
	private b ob;

	}


