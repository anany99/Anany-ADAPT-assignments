package lifecycle;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("lifecycle/lifecycle.xml");
		
//        Samosa s1=(Samosa) context.getBean("samosa1");
//        System.out.println(s1);
        //registering shutdown hook
        context.registerShutdownHook();
        
//        System.out.println("_______________________________");
//        pepsi p1=(pepsi) context.getBean("p1");
//        
//        System.out.println(p1);
        subject subject=(subject) context.getBean("exam");
//        System.out.println(exam);
	}

}
