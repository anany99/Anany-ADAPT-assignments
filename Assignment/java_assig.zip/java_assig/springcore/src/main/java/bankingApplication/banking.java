package bankingApplication;

public class banking {
	private int accountId;
	private int accountBalance;
	private String accountHolderName;
	private String accountType;
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public int getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(int accountBalance) {
		this.accountBalance = accountBalance;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public banking(int accountId, int accountBalance, String accountHolderName, String accountType) {
		super();
		this.accountId = accountId;
		this.accountBalance = accountBalance;
		this.accountHolderName = accountHolderName;
		this.accountType = accountType;
	}
	public banking() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "banking [accountId=" + accountId + ", accountBalance=" + accountBalance + ", accountHolderName="
				+ accountHolderName + ", accountType=" + accountType + "]";
	}
	

}
