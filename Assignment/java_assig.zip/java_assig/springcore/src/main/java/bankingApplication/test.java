package bankingApplication;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class test {

	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("bankingApplication/banking.xml");
        banking banking1=(banking) context.getBean("banking1");
        banking banking2=(banking) context.getBean("banking2");
        
        System.out.println(banking1);
        System.out.println(banking2);

	}

}
