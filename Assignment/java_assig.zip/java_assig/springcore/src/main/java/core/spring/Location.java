package core.spring;

public class Location {
	
	private int zip;
	private String city;
	private String state;
	private String street;
	private String country;
	public int getZip() {
		return zip;
	}
	public void setZip(int zip) {
		this.zip = zip;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public Location(int zip, String city, String state, String street, String country) {
		super();
		this.zip = zip;
		this.city = city;
		this.state = state;
		this.street = street;
		this.country = country;
	}
	public Location() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Location [zip=" + zip + ", city=" + city + ", state=" + state + ", street=" + street + ", country="
				+ country + "]";
	}
}
