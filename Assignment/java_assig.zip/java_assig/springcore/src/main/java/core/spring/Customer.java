package core.spring;

public class Customer {
	
		private int CustomerID;
		private String CustomerName;
		private int CustomerContact;
		private String CustomerAddress;
		public int getCustomerID() {
			return CustomerID;
		}
		public void setCustomerID(int customerID) {
			CustomerID = customerID;
		}
		public String getCustomerName() {
			return CustomerName;
		}
		public void setCustomerName(String customerName) {
			CustomerName = customerName;
		}
		public int getCustomerContact() {
			return CustomerContact;
		}
		public void setCustomerContact(int customerContact) {
			CustomerContact = customerContact;
		}
		public String getCustomerAddress() {
			return CustomerAddress;
		}
		public void setCustomerAddress(String customerAddress) {
			CustomerAddress = customerAddress;
		}
		public Customer(int customerID, String customerName, int customerContact, String customerAddress) {
			super();
			CustomerID = customerID;
			CustomerName = customerName;
			CustomerContact = customerContact;
			CustomerAddress = customerAddress;
		}
		public Customer() {
			super();
			// TODO Auto-generated constructor stub
		}
		@Override
		public String toString() {
			return "Customer [CustomerID=" + CustomerID + ", CustomerName=" + CustomerName + ", CustomerContact="
					+ CustomerContact + ", CustomerAddress=" + CustomerAddress + "]";
		}
}