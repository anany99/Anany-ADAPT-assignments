package core.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
        Location location1=(Location) context.getBean("location1");
        Location location2=(Location) context.getBean("location2");
        
       
        System.out.println(location1);
        System.out.println(location2);
        

    }
}
