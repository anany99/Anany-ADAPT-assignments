package Q_7;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class test {

	public static void main(String[] args) {
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("Q_7");
		Q_7 SpEL = (Q_7) context.getBean("Q_7");
		System.out.println(SpEL.Display());
		context.close();
	}

}