
public class training {

}
