
public class Triangle {
	public void draw() {
		System.out.println("Triangle drawn");
		
	}

}
