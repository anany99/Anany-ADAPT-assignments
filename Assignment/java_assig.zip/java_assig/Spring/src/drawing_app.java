
public class drawing_app {
	
	
	
	public static void main(String[] args) {
		//Triangle Triangle = new Triangle();
		BeanFactory factory = new XmlBeanFactory(new FileSystemResource("spring.xml"));
		Triangle.draw();
		
		
	}

}
