/**
 * 
 */
/**
 * @author anany
 *
 */
module JUnit {
}